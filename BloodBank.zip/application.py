from flask import Flask, redirect, url_for, request,render_template,make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import firebase_admin
from firebase_admin import credentials,db

cred = credentials.Certificate("key.json")
firebase_admin.initialize_app(cred,{'databaseURL':"https://aws-a00bf-default-rtdb.firebaseio.com/:null"})
fdb=db.reference("/")
application = Flask(__name__, template_folder='template')

@application.route('/' ,methods=['GET', 'POST'],)
def hello_world():
    if(request.form):
     if request.form.get('btn') == 'SignupSubmit':
         sun =  request.form['susername']
         spwd =  request.form['spassword']
         fdb.update({"Name":sun})
         fdb.update({"Password":spwd})
    if request.form.get('btn') == 'Home Page':
        return render_template("loginindex.html" )
    if request.form.get('btn') == 'LoginSubmit':
         userdetails = fdb.get()
         lun =  request.form['username']
         lpwd =  request.form['password']
         sun = userdetails['Name']
         spwd =  userdetails['Password']
         error = None
         success=None
         if((sun == lun) and (spwd == lpwd)):
            success='Logged in successfully'
            return render_template("loginindex.html",success=success )
         else:
            error = 'Invalid Credentials. Please try again.'
         return render_template('login.html', error=error)
    if request.form.get('btn')  == 'profile':
         userdetails = fdb.get()
         sun = userdetails['Name']
         spwd =  userdetails['Password']
         return render_template("details.html")
    if request.method == 'POST':
        if request.form.get('action1') == 'Become A Donor':
            return render_template('doner.html')
        elif  request.form.get('action2') == 'Find A Donor?':
            pass 
            return render_template('patient.html')
        else:
            pass

    elif request.method == 'GET':
        return render_template('index.html')
    
    return render_template("index.html")
    

application.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///info.db"
application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
dbs = SQLAlchemy(application)

class Info(dbs.Model):
    sno = dbs.Column(dbs.Integer, primary_key=True)
    Donername = dbs.Column(dbs.String(200), nullable=False)
    bloodT = dbs.Column(dbs.String(500), nullable=False)
    contactME = dbs.Column(dbs.String(500), nullable=False)
 
    def __repr__(self) -> str:
        return f"{self.sno} - {self.Donername}"


@application.route('/successDoner/<Donername>/<bloodT>/<contactME>')
def success( Donername, bloodT, contactME):
    print(Donername)
    print(bloodT)
    print(contactME)
    

    info = Info( Donername = Donername , bloodT = bloodT ,contactME = contactME)
    dbs.session.add(info)
    dbs.session.commit()
    allinfo = Info.query.all()
    return render_template('infotable.html', allinfo = allinfo)


@application.route('/doner', methods = ['POST' , 'GET'])
def Donation():
    if request.method == 'POST':
        print("hello doner")
        user = request.form['nm']
        user2 = request.form['blood']
        user3 = request.form['contact']
        return redirect(url_for('success', Donername = user , bloodT = user2 ,contactME = user3))
    else:
        return render_template('doner.html')


#Patient 
@application.route('/successpatient/<Patientname>')
def successD(Patientname):
   return 'welcome %s' % Patientname

@application.route('/patient', methods = ['POST' , 'GET'])
def patient():
    if request.method == 'POST':
        user = request.form['nm']
        user2 = request.form['contact']
        return redirect(url_for('show', NAME = user , CONTACT = user2))
    else:
        return render_template('patient.html')


@application.route('/show/<NAME>/<CONTACT>')
def show(NAME,CONTACT):
   info = Info(  Donername = "Name", bloodT = "Blood type" ,contactME = "123456789")
   allinfo = Info.query.all()
   return render_template('infotable2.html', allinfo = allinfo , NAME = NAME , CONTACT = CONTACT)



@application.route('/remove')
def pp():
    info = Info(  Donername = "Name", bloodT = "Blood type" ,contactME = "123456789")   
    allinfo = Info.query.all()
    return render_template('infotable.html', allinfo = allinfo)
    


@application.route('/delete/<int:sno>')
def delete(sno):
    info = Info.query.filter_by(sno=sno).first()
    dbs.session.delete(info)
    dbs.session.commit()
    return redirect('/remove')

@application.route('/information')
def information():
    return render_template('information.html')
   

@application.route('/donerINFO')
def donerINFO():
    return render_template('donerINFO.html')


@application.route('/login', methods=['GET', 'POST'])
def login():

    return render_template('login.html')

@application.route('/profile', methods=['GET', 'POST'])
def profile():

    return render_template('details.html')

@application.route('/signup',methods=['GET', 'POST'])
def signup():
    return render_template('signup.html')

@application.route('/sendRequest/<int:sno>/<NAME>/<CONTACT>')
def sendRequest(sno,NAME,CONTACT):
    info = Info.query.filter_by(sno=sno).first()
    return render_template('sendRequest.html', info = info , NAME = NAME , CONTACT = CONTACT)


@application.route('/list3')
def pp3():
    info = Info(  Donername = "Name", bloodT = "Blood type" ,contactME = "123456789")   
    allinfo = Info.query.all()
    return render_template('infotable3.html', allinfo = allinfo)

if __name__ == '__main__':
   application.run(debug = True, port = 8000)